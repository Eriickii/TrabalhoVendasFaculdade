## Trabalho POO

## Itens a terminar na aplicação
```
- Encontre o erro das informações dúplicadas e faça a correção.
- Construa um menu para melhorar a aplicação.
- Seria ideal que cada cliente, produdo e pedido tivessem um codigo único.
- Possibilitar o cancelamento do item do Produto, voltando o produto para o estoque.
- Possibilitar o cancelamento da venda, voltando todos os produtos para o estoque.
